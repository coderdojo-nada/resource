function drawRegularPolygon(r, n) {
    beginShape();
    for (let i = 0; i < n; i++) {
        let x = r * cos(radians(360 / n * i)); //斜辺 * cosθ
        let y = r * sin(radians(360 / n * i)); //斜辺 * sinθ
        vertex(x, y);
    }
    endShape();
}
// 半径1の円に内接するn角形の半周の長さを求める
function 半径1の円に内接するn角形の半周の長さを求める(n) {
    // sin([n角形の中心角]÷2) == n角形の１辺の半分の長さ
    let 半径1の円に内接するn角形の１辺の半分の長さ = sin(radians(180 / n));
    // n角形の半周の長さ
    let 半径1の円に内接するn角形の半周の長さ = 半径1の円に内接するn角形の１辺の半分の長さ * n;
    return 半径1の円に内接するn角形の半周の長さ;
}
// 半径1の円に外接するn角形の半周の長さを求める
function 半径1の円に外接するn角形の半周の長さを求める(n) {
    // 直角三角形の対辺を求める 隣辺 × tanθ
    let 半径1の円に外接するn角形の１辺の半分の長さ = 1 * tan(radians(180 / n));
    // n角形の半周の長さ
    let 半径1の円に外接するn角形の半周の長さ = 半径1の円に外接するn角形の１辺の半分の長さ * n;
    return 半径1の円に外接するn角形の半周の長さ;
}
let n = 3 //n角形のn
function setup() {
    createCanvas(windowWidth, windowHeight);
    background(100);
    translate(width / 2, height / 2); //縦横ともに半分ずつ動かして(0,0)を中心にする
    frameRate(16); // 速さは1秒間に n回、書きなおす（draw()関数を呼び出す）
    textSize(24);
    textAlign(LEFT);
    fill("cyan");
}

function draw() {
    background(100);
    translate(width / 2, height / 2); //縦横ともに半分ずつ動かして(0,0)を中心にする
    n++ // n角形のnを増やしていく
    drawRegularPolygon(100, n);
    text(n + "角形", -400, -300);
    // n角形の半周の長さ が [半径が1の円周]÷2 == [1×2×円周率]÷2 に近づいていく
    text("半径1の円に内接するn角形の半周の長さ: " + 半径1の円に内接するn角形の半周の長さを求める(n), -400, -250);
    text("半径1の円に外接するn角形の半周の長さ: " + 半径1の円に外接するn角形の半周の長さを求める(n), -400, -200);
}