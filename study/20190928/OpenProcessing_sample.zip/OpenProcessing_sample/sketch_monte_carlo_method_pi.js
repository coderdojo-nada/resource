let test_count = 0 //テストした回数
let hit_count = 0 //ヒットした(円の内側に入った)回数

// はじめに１回だけ初期化を実行
function setup() {
    createCanvas(windowWidth, windowHeight);
    background("white"); // 背景を白で塗りつぶす
    translate(width / 2, height / 2); //縦横ともに半分ずつ動かして(0,0)を中心にする
    frameRate(24); // 速さは1秒間に n回、書きなおす（draw()関数を呼び出す）
    textSize(24); // 文字の大きさ
    textAlign(LEFT); // 文字を左寄せ
    noStroke(); // 枠線を表示しない
}

// １秒間に[frameRate]回数、実行
function draw() {
    test_count += 1 // テスト回数をカウント
    let x = Math.floor(Math.random()*100) + 1 // x座標を1から100までの間でランダムに求める
    let y = Math.floor(Math.random()*100) + 1 // y座標を1から100までの間でランダムに求める
    let d = Math.sqrt((x-50)**2 + (y-50)**2) // 中心と点との距離
    if (d <= 50) { // 中心との距離が50以内
        fill("red");
        hit_count += 1
    } else { // 中心との距離が50より大きい
        fill("green");
    }

    // 描画するたび、そのときの円周率を求める
    p = hit_count / test_count  // 点が円の中にある確率
    pi = p * 4   // 円周率
    
    // 点を描く
    ellipse(x, y, 1, 1)

    // 文字の欄をクリア
    fill("white")
    rect(200, 0, 800, 50)
    
    // 文字を表示
    fill("black")
    text("テスト回数: " + test_count + " π: " + pi, 200, 30)
}
