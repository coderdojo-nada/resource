import pyxel


class App:
    def __init__(self):
        pyxel.init(100, 110, caption="Pyxel Life Game")
        self.is_alive = [[False] * 50 for i in range(50)]
        self.is_alive_next = [[False] * 50 for i in range(50)]

        self.is_moving = False

        pyxel.mouse(True)
        pyxel.run(self.update, self.draw)

    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()

        if pyxel.btnp(pyxel.MOUSE_LEFT_BUTTON):
            x_n, y_n = pyxel.mouse_x, pyxel.mouse_y

            if 101 <= y_n <= 110:
                if 59 <= x_n <= 78:
                    self.is_moving = False
                elif 79 <= x_n <= 100:
                    self.is_moving = True

            if 0 <= x_n <= 99 and 0 <= y_n <= 99:
                self.is_alive[x_n // 2][y_n // 2] = not self.is_alive[x_n // 2][y_n // 2]
                self.is_alive_next[x_n // 2][y_n // 2] = not self.is_alive_next[x_n // 2][y_n // 2]

        if self.is_moving:

            x = [1, 1, 0, -1, -1, -1, 0, 1]
            y = [0, 1, 1, 1, 0, -1, -1, -1]

            for i in range(1, 49):
                for j in range(1, 49):
                    alive_num = 0

                    for k in range(8):
                        if self.is_alive[i + x[k]][j + y[k]]:
                            alive_num += 1

                    if self.is_alive[i][j]:
                        if alive_num <= 1:  # 過疎による死滅
                            self.is_alive_next[i][j] = False
                        elif alive_num >= 4:  # 過密による死滅
                            self.is_alive_next[i][j] = False
                    else:
                        if alive_num == 3:  # 誕生
                            self.is_alive_next[i][j] = True

            for i in range(1, 49):
                for j in range(1, 49):
                    self.is_alive[i][j] = self.is_alive_next[i][j]

    def draw(self):
        pyxel.cls(0)

        for i in range(50):
            for j in range(50):
                if self.is_alive[i][j]:
                    pyxel.pix(2*i, 2*j, 8)
                    pyxel.pix(2*i, 2*j+1, 8)
                    pyxel.pix(2*i+1, 2*j, 8)
                    pyxel.pix(2*i+1, 2*j+1, 8)

        pyxel.text(1, 102, "Time: {:0>6}".format(pyxel.frame_count), 10)
        pyxel.text(60, 102, "STOP", 6 if self.is_moving else 3)
        pyxel.text(80, 102, "START", 3 if self.is_moving else 6)


App()