from random import randint

import pyxel

class App:
    def __init__(self):
        pyxel.init(
         192, # ウィンドウサイズ 幅 8*24
         128, # ウィンドウサイズ 高さ 8*16
         caption="Pyxel Test" # ウィンドウタイトル
         )

        pyxel.load("/Users/tsuji/pyxel_examples/assets/test01.pyxel")

        self.player_x = 0
        self.player_y = 0

        pyxel.run(self.update, self.draw)

    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()

        self.update_player()

    def update_player(self):
        if pyxel.btn(pyxel.KEY_LEFT):
            self.player_x = max(self.player_x - 2, 0)

        if pyxel.btn(pyxel.KEY_UP):
            self.player_y = max(self.player_y - 2, 0)

        if pyxel.btn(pyxel.KEY_RIGHT):
            self.player_x = min(self.player_x + 2, pyxel.width - 16)

        if pyxel.btn(pyxel.KEY_DOWN):
            self.player_y = min(self.player_y + 2, pyxel.height - 16)

    def draw(self):
        # 指定した色でクリア
        pyxel.cls(12)

        # draw map
        pyxel.bltm(
            0, # コピー先 x
            0, # コピー先 y
            0,  # 何番目のイメージバンクか(コピー元)
            0,  # イメージバンク(コピー元)のｘ座標
            0,  # イメージバンク(コピー元)のy座標
            24, # イメージバンク(コピー元)の幅
            16, # イメージバンク(コピー元)の高さ
            12, # 指定した色が透明になる
        )

        # draw text
        pyxel.text(
         5, # 文字を表示するx座標
         4, # 文字を表示するy座標
         "CoderDojo Nada", # 文字列（日本語不可）
         1 # 文字の色
         )

        # draw player
        pyxel.blt(
            self.player_x, # コピー先 x
            self.player_y, # コピー先 y
            0,  # 何番目のイメージバンクか(コピー元)
            0,  # イメージバンク(コピー元)のｘ座標
            0,  # イメージバンク(コピー元)のy座標
            16, # イメージバンク(コピー元)の幅
            16, # イメージバンク(コピー元)の高さ
            8, # 指定した色が透明になる
        )

App()
